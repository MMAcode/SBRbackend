package makarov.learning.model;

public interface QuizProjection_NameId {
    String getId();
    String getTitle();
}
