# INSERT INTO books (title, isbn,copies_total)values("Hobit",1234567890123,5),("7 habits of efective people",1234567890124,25);
# INSERT INTO authors (name)values("Tolkien"),("Stephen Covey");
# INSERT INTO users (name)values("Tolkien");