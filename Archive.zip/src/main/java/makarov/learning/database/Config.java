package makarov.learning.database;

public class Config {
    // @Bean // can be specified here or in application.properties
    // DataSource dataSource(){
    //     DriverManagerDataSource dataSource = new DriverManagerDataSource();
    //     dataSource.setUsername();
    //     dataSource.setPassword();
    //     dataSource.setUrl();
    // }
}
